# Electric Vehicle Charge and Range Analysis

A Data Analytics & Visualization Project using Tableau — Internship Project
(Internship duration: 25 May 2026 onward)

## Repository Structure

```
GitHub Repository
│
├── 01_Ideation_Phase
│   ├── Problem_Statement.docx
│   ├── Empathy_Map_Canvas.docx
│   └── Brainstorming.docx
│
├── 02_Requirement_Analysis
│   ├── Customer_Journey_Map.docx
│   ├── Solution_Requirement.docx
│   ├── Data_Flow_Diagram_and_User_Stories.docx
│   └── Technology_Stack.docx
│
├── 03_Project_Design_Phase
│   ├── Problem_Solution_Fit.docx
│   ├── Proposed_Solution.docx
│   └── Solution_Architecture.docx
│
├── 04_Project_Planning_Phase
│   └── Project_Planning_Template.docx
│
├── 05_Project_Development_Phase
│   ├── 1st_PDF_Preprocessing_and_Business_Questions.docx
│   ├── 2nd_PDF_Dashboard_Story_Screenshots_Tableau_Links.docx
│   └── Dataset
│       ├── Dataset_README.docx
│       ├── ElectricCarData_Clean.csv        (add your raw file here)
│       ├── EVIndia.csv                      (add your raw file here)
│       ├── Cheapestelectriccars-EVDatabase.csv  (add your raw file here)
│       └── electric_vehicle_charging_station_list.csv (add your raw file here)
│
├── 06_Performance_Testing
│   └── Performance_Testing_Template.docx
│
└── 07_Doc_and_Demo
    ├── Final_Report.pdf
    └── Demonstration_Video.docx  (add your recorded video link here)
```

## How to push to GitHub

```bash
git init
git add .
git commit -m "Initial commit: EV Charge and Range Analysis project structure"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

## Notes
- All dates in the documents are set based on the internship start date of **25 May 2026**, following the 6-sprint (1 week each) schedule used in the final report.
- Drop your four raw CSV files into `05_Project_Development_Phase/Dataset/` before pushing.
- Add your Tableau `.twbx` workbook file and the recorded demo video link before final submission.
